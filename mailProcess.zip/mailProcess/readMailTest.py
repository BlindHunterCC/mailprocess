# pip install pywin32
# python -m pip install -U pip
import os
import sys
from win32com.client.gencache import EnsureDispatch as Dispatch
# 引数
# sys.argv[1]：アドレス
# sys.argv[2]：テーマ
# xl-hk-zhaozhx@nec.cn "Mail Test"

__author__ = 'Evan'
ret = False


def read_outlook_mailbox():
    global ret
    outlook = Dispatch('Outlook.Application').GetNamespace('MAPI')
    root_folder = outlook.Folders.Item(1)
    for folder in root_folder.Folders:
        if folder.Name == "test":
            # inbox = outlook.GetDefaultFolder(6)  # 受信トレイ
            mails = folder.Items
            mails.Sort('[ReceivedTime]', True)  # 時間ソート
            for index in range(1, mails.Count+1):
                print(f'メール[{index}]を取込中。。。')
                mail = mails.Item(index)
                print(f'受信時間：{str(mail.ReceivedTime)[:-6]}')
                print(f'発送元：{mail.SenderName}')
                print('アドレス：{}'.format(mail.To))
                print('CC：{}'.format(mail.CC))
                print('テーマ：{}'.format(mail.Subject))
                print('本文：{}'.format(mail.Body))
                print('添付数：{}'.format(mail.Attachments.Count))
                # print('MessageID：{}'.format(mail.EntryID))
                # 添付ファイルのダウンロード
                attachment = mail.Attachments
                for each in attachment:
                    save_attachment_path = os.getcwd()  # 該当パスに保存
                    each.SaveAsFile(r'{}\{}'.format(save_attachment_path, each.FileName))
                    print('添付ファイル（{}）を保存済み'.format(each.FileName))
                # メールの削除
                # mail.Delete()
                if mail.To == sys.argv[1] and mail.Subject == sys.argv[2]:
                    ret = True


if __name__ == '__main__':
    read_outlook_mailbox()
    if ret:
        sys.exit(1)
    else:
        sys.exit(-1)
