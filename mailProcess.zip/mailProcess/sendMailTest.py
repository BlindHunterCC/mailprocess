# pip install pywin32
# python -m pip install -U pip
from win32com import client as win32

__author__ = 'Evan'


def send_mail():
    outlook = win32.Dispatch('Outlook.Application')

    mail_item = outlook.CreateItem(0)
    mail_item.Recipients.Add('xl-hk-zhaozhx@nec.cn')
    mail_item.Subject = 'Mail Test'
    mail_item.BodyFormat = 2  # HTMLとして
    mail_item.HTMLBody = """
    <H2>Hello, This is a test mail.</H2>
    Hello World.
    """
    # mail_item.Attachments.Add('test.csv')  # 添付ファイル追加
    mail_item.Send()


if __name__ == '__main__':
    send_mail()
